<?php
/**
 * Class: csci330fa20
 * User: Brian Taylor
 * Date: 10/10/2020
 */

$pagename = "Home";

//include the header at the top
include "includes/header.php";
include "includes/connect.php";

// assign cardid
$cardid = $_POST['cardid'];


$selectcard = "DELETE FROM cards
                        WHERE cardid = :bvcardid";
$result_card = $pdo->prepare($selectcard);
$result_card->bindValue(':bvcardid', $cardid);
$result_card->execute();


echo '<h2>Record Successfully Deleted</h2>';

				echo '<div class="center"><form action="index.php" method="">';
                echo '<input type="submit" name="return" class="btn-sm btn-secondary" value="return">';
				echo '</form>';




	

//include footer at the bottom
include "includes/footer.php";
?>