<?php

//header include file
?>
<footer>
    <?php

        $author = "Created by: CSCI 490 Team 2";
        echo "$author <br>";
        echo date('l \t\h\e jS');

    ?>
</footer>
</body>
</html>