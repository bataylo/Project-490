<?php
session_start();

$pagetitle = "Update Card";

require_once 'includes/header.php';
require_once 'includes/connect.php';

// assign cardid
$cardid = $_POST['cardid'];

// get the positions
$game = 'SELECT * FROM cardgame';
$result_g = $pdo->prepare($game);
$result_g->execute();

$condition = 'SELECT * FROM cardcondition';
$result_c = $pdo->prepare($condition);
$result_c->execute();

$set = 'SELECT * FROM cardset';
$result_s = $pdo->prepare($set);
$result_s->execute();


// get the card info
$selectcard = "SELECT * FROM cards
			INNER JOIN cardcondition ON cards.cardconditionid = cardcondition.cardconditionid
			INNER JOIN cardset ON cards.cardsetid = cardset.cardsetid
			INNER JOIN cardgame ON cards.cardgameid = cardgame.cardgameid 
                        WHERE cardid = :bvcardid";
$result_card = $pdo->prepare($selectcard);
$result_card->bindValue(':bvcardid', $cardid);
$result_card->execute();
$row_card = $result_card->fetch();



$formfield['ffcardname'] = $row_card['cardname'];
$formfield['ffcardgamename'] = $row_card['cardgamename'];
$formfield['ffcardcondition'] = $row_card['cardcondition'];
$formfield['ffcardsetname'] = $row_card['cardsetname'];
$formfield['ffcardprice'] = $row_card['cardprice'];
$formfield['ffcardquantity'] = $row_card['cardquantity'];
$formfield['ffcardgameid'] = $row_card['cardgameid'];
$formfield['ffcardconditionid'] = $row_card['cardconditionid'];
$formfield['ffcardsetid'] = $row_card['cardsetid'];


//NECESSARY VARIABLES
$errormsg = "";
$cname_err = $cardgame_err = $ccondition_err = $cset_err = $cprice_err = "";
$cquan_err = "";

if( isset($_POST['submit']) )
{
    $formfield['ffcardname'] = trim($_POST['cardname']);
    $formfield['ffcardgameid'] = trim($_POST['cardgame']);
    $formfield['ffcardconditionid'] = trim($_POST['cardcondition']);
    $formfield['ffcardsetid'] = trim($_POST['cardset']);
    $formfield['ffcardprice'] = trim($_POST['cardprice']);
    $formfield['ffcardquantity'] = trim($_POST['cardquantity']);


    if(empty($formfield['ffcardname'])){$cname_err = "Card name cannot be empty.";}
    if(empty($formfield['ffcardgameid'])){$cgame_err = "Card Game cannot be empty.";}
    if(empty($formfield['ffcardconditionid'])){$ccondition_err = "Card Condition cannot be empty.";}
    if(empty($formfield['ffcardsetid'])){$cset_err = "Card set cannot be empty.";}
    if(empty($formfield['ffcardprice'])){$cprice_err = "Card price cannot be empty.";}
    if(empty($formfield['ffcardquantity'])){$cquan_err = "Quantity cannot be empty.";}
    

    if(empty($cname_err) && empty($cgame_err) && empty($ccondition_err) && empty($cset_err) && empty($cprice_err) &&
        empty($cquan_err))
    {
        try
        {
            $sqlinsert = "UPDATE cards SET cardname = :bvcardname, cardgameid = :bvcardgameid, cardconditionid = :bvcardconditionid, 
                                              cardsetid = :bvcardsetid, cardprice = :bvcardprice, cardquantity = :bvcardquantity
                                           WHERE cardid = :bvcardid";
            $sqlinsert = $pdo->prepare($sqlinsert);
            $sqlinsert->bindValue(':bvcardid', $cardid);
            $sqlinsert->bindValue(':bvcardname', $formfield['ffcardname']);
            $sqlinsert->bindValue(':bvcardgameid', $formfield['ffcardgameid']);
            $sqlinsert->bindValue(':bvcardconditionid', $formfield['ffcardconditionid']);
            $sqlinsert->bindValue(':bvcardsetid', $formfield['ffcardsetid']);
            $sqlinsert->bindValue(':bvcardprice', $formfield['ffcardprice']);
            $sqlinsert->bindValue(':bvcardquantity', $formfield['ffcardquantity']);
            $sqlinsert->execute();

            echo '<br><div class="alert alert-success text-center" style="width:40%; margin: 0 30% 0 30%; text-align:center role="alert">Card Information Updated Successfully.</div><br>';

        }
        catch(PDOException $e)
        {
            echo 'Error!' .$e->getMessage();
            exit();
        }
    }
}//if isset submit


    ?>

    <div class="container">
        <div class="row">
            <div class="col-md-6 mx-auto">
                <div class="card card-body bg-light mt-5">
                    <h2>Update Card Information</h2>
                    <form method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>" name="form">
						
						<div class='center'>
                        <div class="form-group row">
						<label class="col-sm-4 col-form-label" for="cardname">Card Name:</label>
                            <input type="text" name="cardname" placeholder="Card Name"
                                   class="form-control <?php echo (!empty($cname_err)) ? 'is-invalid' : ''; ?>"
                                   value="<?php if (isset($formfield['ffcardname'])) {
                                       echo $formfield['ffcardname'];
                                   } ?>"/>
                            <span class="invalid-feedback"><?php echo $cname_err; ?></span>
                        </div>
                        </div>
						
						<br><br>
						
						<div class='center'>
						<div class="form-group row">
                            <label class="col-sm-4 col-form-label" for="cardgame">Card Gane:</label>
                            <div class="col-sm-8">
                                <select name="cardgame" id="cardgame" required
                                        class="form-control <?php echo (!empty($cardgame_err)) ? 'is-invalid' : ''; ?>">
                                    <option value="">Select Card Game</option>
                                    <?php
                                    while ($row_g = $result_g->fetch())
                                    {
                                        if ($row_g['cardgameid'] == $formfield['ffcardgameid']) {
                                            $checker = 'selected';
                                        } else {
                                            $checker = '';
                                        }
                                        echo '<option value="' . $row_g['cardgameid'] . '" ' . $checker . '>' . $row_g['cardgamename'] . '</option>';
                                    }
                                    ?>
                                </select>
                                <span class="invalid-feedback"><?php echo $cardgame_err; ?></span>
                            </div>
                        </div>
						</div>
						
						<br><br>
						
						<div class='center'>
						<div class="form-group row">
                            <label class="col-sm-4 col-form-label" for="cardcondition">Card Condition:</label>
                            <div class="col-sm-8">
                                <select name="cardcondition" id="cardcondition" required
                                        class="form-control <?php echo (!empty($cardgame_err)) ? 'is-invalid' : ''; ?>">
                                    <option value="">Select Card Condition</option>
                                    <?php
                                    while ($row_c = $result_c->fetch())
                                    {
                                        if ($row_c['cardconditionid'] == $formfield['ffcardconditionid']) {
                                            $checker = 'selected';
                                        } else {
                                            $checker = '';
                                        }
                                        echo '<option value="' . $row_c['cardconditionid'] . '" ' . $checker . '>' . $row_c['cardcondition'] . '</option>';
                                    }
                                    ?>
                                </select>
                                <span class="invalid-feedback"><?php echo $ccondition_err; ?></span>
                            </div>
                        </div>
						</div>
						
						<br><br>
						
						<div class='center'>
						<div class="form-group row">
                            <label class="col-sm-4 col-form-label" for="cardset">Card Set:</label>
                            <div class="col-sm-8">
                                <select name="cardset" id="cardset" required
                                        class="form-control <?php echo (!empty($cardgame_err)) ? 'is-invalid' : ''; ?>">
                                    <option value="">Select Card Set</option>
                                    <?php
                                    while ($row_s = $result_s->fetch())
                                    {
                                        if ($row_s['cardsetid'] == $formfield['ffcardsetid']) {
                                            $checker = 'selected';
                                        } else {
                                            $checker = '';
                                        }
                                        echo '<option value="' . $row_s['cardsetid'] . '" ' . $checker . '>' . $row_s['cardsetname'] . '</option>';
                                    }
                                    ?>
                                </select>
                                <span class="invalid-feedback"><?php echo $cset_err; ?></span>
                            </div>
                        </div>
						</div>
						
						<br><br>
						
						<div class='center'>
						<div class="form-group row">
						<label class="col-sm-4 col-form-label" for="cardprice">Card Price:</label>
                            <input type="text" name="cardprice" placeholder="Card Price"
                                   class="form-control <?php echo (!empty($cname_err)) ? 'is-invalid' : ''; ?>"
                                   value="<?php if (isset($formfield['ffcardprice'])) {
                                       echo $formfield['ffcardprice'];
                                   } ?>"/>
                            <span class="invalid-feedback"><?php echo $cprice_err; ?></span>
                        </div>
						</div>
						
						<br><br>
						
						<div class='center'>
						<div class="form-group row">
						<label class="col-sm-4 col-form-label" for="cardquantity">Card Quantity:</label>
                            <input type="text" name="cardquantity" placeholder="Card Quantity"
                                   class="form-control <?php echo (!empty($cname_err)) ? 'is-invalid' : ''; ?>"
                                   value="<?php if (isset($formfield['ffcardquantity'])) {
                                       echo $formfield['ffcardquantity'];
                                   } ?>"/>
                            <span class="invalid-feedback"><?php echo $cquan_err; ?></span>
                        </div>
						</div>
						
						<br><br>

						<div class='center'>
                        <div class="form-row">
                            <div class="col text-center">
                                <input type="hidden" name="cardid" value="<?php echo $cardid ?>">
                                <input type="submit" value="Update" name="submit" class="btn btn-secondary">
                            </div>
                        </div>
						</div>
                    </form>
                </div>
            </div>
        </div>
        <br>
    </div>
    <?php

include_once 'includes/footer.php';
?>